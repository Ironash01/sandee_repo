extends TextureRect

var slot_index: int = -1

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP

func _can_drop_data(_at_position: Vector2, data: Variant) -> bool:
	if not (data is Dictionary):
		return false
	if not data.has("from_index"):
		return false
	# Accept drags from inventory only
	return data.get("source", "") == "inventory"

func _drop_data(_at_position: Vector2, data: Variant) -> void:
	var from_idx: int = data["from_index"]
	if from_idx < 0 or from_idx >= Global.Inventory.size():
		return
	var dragged_item: Variant = Global.Inventory[from_idx]
	if dragged_item == null:
		return
	# Swap: existing hotbar item goes back to the inventory slot
	var existing: Variant = Global.Hotbar[slot_index]
	Global.Hotbar[slot_index]    = dragged_item
	Global.Inventory[from_idx]   = existing
	Global.Hotbar_updated.emit()
	Global.Inventory_updated.emit()
