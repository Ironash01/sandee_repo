extends Node2D

# ── Direction map (matches sprite folder names) ───────────────────
const DIRS: Array = [
	{"name": "south",      "vec": Vector2( 0,  1)},
	{"name": "north",      "vec": Vector2( 0, -1)},
	{"name": "east",       "vec": Vector2( 1,  0)},
	{"name": "west",       "vec": Vector2(-1,  0)},
	{"name": "south-east", "vec": Vector2( 1,  1)},
	{"name": "south-west", "vec": Vector2(-1,  1)},
	{"name": "north-east", "vec": Vector2( 1, -1)},
	{"name": "north-west", "vec": Vector2(-1, -1)},
]

var _player_nearby: bool    = false
var _ui:            Control = null
var _last_dir:      String  = "south"

@onready var _sprite:  AnimatedSprite2D = $Sprite2D
@onready var _interact: Area2D          = $InteractArea

func _ready() -> void:
	_sprite.sprite_frames = _build_frames()
	_sprite.play("walk_south")
	_interact.body_entered.connect(_on_body_entered)
	_interact.body_exited.connect(_on_body_exited)
	# Spawn the code editor UI on its own CanvasLayer
	var ui_scene: PackedScene = load("res://scenes/ui/LuaEditorUI.tscn") as PackedScene
	var canvas := CanvasLayer.new()
	canvas.layer        = 12
	canvas.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(canvas)
	_ui = ui_scene.instantiate() as Control
	canvas.add_child(_ui)
	_ui.visible = false

# ── Build SpriteFrames from individual PNGs ───────────────────────
func _build_frames() -> SpriteFrames:
	var sf := SpriteFrames.new()
	sf.remove_animation("default")
	for d in DIRS:
		var dir: String  = d["name"]
		var anim: String = "walk_" + dir.replace("-", "_")
		sf.add_animation(anim)
		sf.set_animation_speed(anim, 10.0)
		sf.set_animation_loop(anim, true)
		for f in range(8):
			var path := "res://sprites/char/lua/animations/Walking-c1c75e91/%s/frame_%03d.png" % [dir, f]
			sf.add_frame(anim, load(path) as Texture2D)
	return sf

# ── Interaction ───────────────────────────────────────────────────
func _input(event: InputEvent) -> void:
	if not _player_nearby or _ui == null:
		return
	if event is InputEventMouseButton \
			and event.pressed \
			and event.button_index == MOUSE_BUTTON_LEFT:
		_ui.visible = not _ui.visible
		get_tree().paused = _ui.visible

func _on_body_entered(body: Node) -> void:
	if body.is_in_group("Player"):
		_player_nearby = true

func _on_body_exited(body: Node) -> void:
	if body.is_in_group("Player"):
		_player_nearby = false
		if _ui != null and _ui.visible:
			_ui.visible    = false
			get_tree().paused = false
